#!/usr/bin/env python3
import os
import subprocess
from colorama import Fore, init

init()
MODEL = "llama3:8b"
CONTEXT_LIMIT = 100  # Max messages to remember
CHAT_FILE = "chat_history.txt"

def load_chat_file():
    """Load chat history from file (if it exists)."""
    if os.path.exists(CHAT_FILE):
        with open(CHAT_FILE, "r") as f:
            return [line.strip().split("|", 1) for line in f if "|" in line]
    return []

def save_chat_file(context):
    """Save chat history to file."""
    with open(CHAT_FILE, "w") as f:
        for role, msg in context:
            f.write(f"{role}|{msg}\n")

def summarize_chat(context):
    """Ask the AI to summarize the conversation."""
    if not context:
        print(f"{Fore.YELLOW}No chat history to summarize!{Fore.RESET}")
        return

    # Build a prompt for summarization
    summary_prompt = (
        "Summarize this conversation in 3-4 sentences. Be concise:\n\n"
        + "\n".join(
            f"User: {msg[1]}" if msg[0] == "User" else f"AI: {msg[1]}"
            for msg in reversed(context[-CONTEXT_LIMIT:])
        )
    )

    try:
        result = subprocess.run(
            ["ollama", "run", MODEL],
            input=summary_prompt,
            text=True, capture_output=True, check=True
        )
        summary = result.stdout.strip()
        print(f"\n{Fore.GREEN}=== Summary ==={Fore.RESET}\n{summary}\n")
    except Exception as exc:
        print(f"{Fore.RED}Oops! Error summarizing: {exc}{Fore.RESET}")

def run_ollama_chat():
    print(f"{Fore.GREEN}=== Ollama AI Terminal (with Summarize & Auto-Save!) ===")
    print("Commands:\n"
          "  'exit'/'quit' → Exit\n"
          "  'clear' → Wipe screen\n"
          "  'reset' → Forget context (saves empty chat)\n"
          "  'summarize' → AI recaps your conversation\n"
          "  'save' → Manually save (auto-saves on exit/reset)\n")

    # Load existing chat
    context = load_chat_file()

    while True:
        try:
            user_input = input(f"{Fore.GREEN}$ {Fore.RESET}")

            if user_input.lower() in ("exit", "quit"):
                break  # Auto-save on exit
            elif user_input == "clear":
                subprocess.run("cls" if os.name == "nt" else "clear", shell=True)
                continue
            elif user_input == "reset":
                context = []
                print(f"{Fore.YELLOW}Context reset!{Fore.RESET}")
                save_chat_file(context)  # Save empty state
                continue
            elif user_input in ("save", "summarize"):
                if user_input == "save":
                    save_chat_file(context)
                    print(f"{Fore.GREEN}Chat saved to {CHAT_FILE}{Fore.RESET}")
                else:  # summarize
                    summarize_chat(context)
                continue

            # Build the prompt with context (if any)
            if context:
                history_text = "\n".join(
                    f"User: {msg[1]}" if msg[0] == "User" else f"AI: {msg[1]}"
                    for msg in reversed(context[-CONTEXT_LIMIT:])
                )
                prompt = f"{history_text}\n\nUser: {user_input}"
            else:
                prompt = user_input

            # Call Ollama (same fallback logic)
            try:
                result = subprocess.run(
                    ["ollama", "run", MODEL],
                    input=prompt,
                    text=True, capture_output=True, check=True
                )
            except subprocess.CalledProcessError as e:
                result = subprocess.run(
                    ["ollama", "run", MODEL, prompt],
                    text=True, capture_output=True, check=True
                )

            ai_response = result.stdout.strip()
            print(f"\n{Fore.GREEN}AI:{Fore.RESET} {ai_response}\n")

            # Save this exchange to context (if it’s not empty)
            if ai_response:
                context.append(("User", user_input))
                context.append(("AI", ai_response))

        except KeyboardInterrupt:
            print("\nCtrl+C detected. Exiting...")
            break
        except Exception as exc:
            print(f"{Fore.RED}Oops! Error: {exc}{Fore.RESET}")

    # Auto-save on exit
    save_chat_file(context)
    print(f"\n{Fore.GREEN}Chat saved to {CHAT_FILE}. Goodbye!{Fore.RESET}")

if __name__ == "__main__":
    run_ollama_chat()
